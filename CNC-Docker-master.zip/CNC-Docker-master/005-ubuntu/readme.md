```sh
$ docker run -it ameen /bin/bash
```
